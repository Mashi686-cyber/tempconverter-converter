package com.example.tempconverter.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.tempconverter.model.TemperatureLog;
import com.example.tempconverter.service.TemperatureService;

@RestController
@RequestMapping("/api/temperatures")
public class TemperatureController {

    private final TemperatureService service;

    public TemperatureController(TemperatureService service) {
        this.service = service;
    }


    @PostMapping("/convert")
    public TemperatureLog convert(
            @RequestParam double value,
            @RequestParam String unit) {

        return service.convert(value, unit);
    }



    @GetMapping("/warning-check")
    public String warningCheck(
            @RequestParam double value,
            @RequestParam String unit) {

        boolean warning = service.checkWarning(value, unit);

        if (warning) {
            return "WARNING: Temperature is dangerously hot!";
        }

        return "Temperature is safe.";
    }



    @GetMapping("/history")
    public List<TemperatureLog> getHistory() {

        return service.getHistory();

    }



    @DeleteMapping("/history")
    public String clearHistory() {

        service.clearHistory();

     return "History cleared successfully.";

    }

}