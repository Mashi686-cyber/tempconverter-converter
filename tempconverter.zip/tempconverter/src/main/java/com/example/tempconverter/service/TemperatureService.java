package com.example.tempconverter.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.tempconverter.model.TemperatureLog;
import com.example.tempconverter.repository.TemperatureLogRepository;

@Service
public class TemperatureService {

    private final TemperatureLogRepository repository;

    public TemperatureService(TemperatureLogRepository repository) {
        this.repository = repository;
    }


    public TemperatureLog convert(double value, String unit) {

        double convertedValue;
        String convertedUnit;


        if (unit.equalsIgnoreCase("C") || unit.equalsIgnoreCase("CELSIUS")) {

            convertedValue = (value * 9 / 5) + 32;
            convertedUnit = "FAHRENHEIT";

        } 
        
        else if (unit.equalsIgnoreCase("F") || unit.equalsIgnoreCase("FAHRENHEIT")) {

            convertedValue = (value - 32) * 5 / 9;
            convertedUnit = "CELSIUS";

        } 
        
        else {

            throw new IllegalArgumentException("Invalid unit");

        }


        TemperatureLog log = new TemperatureLog(
                value,
                unit,
                convertedValue,
                convertedUnit
        );


        return repository.save(log);

    }




    public boolean checkWarning(double value, String unit) {

        double celsius;


        if (unit.equalsIgnoreCase("F") || unit.equalsIgnoreCase("FAHRENHEIT")) {

            celsius = (value - 32) * 5 / 9;

        } 
        
        else {

            celsius = value;

        }


        return celsius > 38;

    }




    public List<TemperatureLog> getHistory() {

        return repository.findAll();

    }




    public void clearHistory() {

        repository.deleteAll();

    }

}